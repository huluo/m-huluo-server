__title__ = 'tld'
__version__ = '0.6'
__build__ = 0x000006
__author__ = 'Artur Barseghyan'
__all__ = ('get_tld', 'update_tld_names')

from tld.utils import get_tld, update_tld_names
